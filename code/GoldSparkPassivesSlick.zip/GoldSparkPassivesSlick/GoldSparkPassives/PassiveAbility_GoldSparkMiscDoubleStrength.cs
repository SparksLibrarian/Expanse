﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoldSparkPassives
{
    public class PassiveAbility_DoubleStrength : PassiveAbilityBase
    {
        public override void OnAddKeywordBufByCardForEvent(
          KeywordBuf keywordBuf,
          int stack,
          BufReadyType readyType)
        {
            if (keywordBuf != KeywordBuf.Strength)
                return;
            if (readyType == BufReadyType.ThisRound)
            {
                this.owner.bufListDetail.AddKeywordBufThisRoundByEtc(keywordBuf, stack);
            }
            else
            {
                if (readyType != BufReadyType.NextRound)
                    return;
                this.owner.bufListDetail.AddKeywordBufByEtc(keywordBuf, stack);
            }
        }
    }
}
