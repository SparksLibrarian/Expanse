﻿using System;

namespace GoldSparkPassives
{
    public class PassiveAbility_GoldSparkLonelyattheTop : PassiveAbilityBase
    {
        public override void OnRoundEnd()
        {
            if (BattleObjectManager.instance.GetAliveList(this.owner.faction).Count != 1)
                return;
            this.owner.bufListDetail.AddKeywordBufByCard(KeywordBuf.Strength, 2, this.owner);
            this.owner.bufListDetail.AddKeywordBufByCard(KeywordBuf.Endurance, 2, this.owner);
            this.owner.bufListDetail.AddKeywordBufByCard(KeywordBuf.Quickness, 2, this.owner);
            this.owner.bufListDetail.AddKeywordBufByCard(KeywordBuf.Protection, 2, this.owner);
            this.owner.bufListDetail.AddKeywordBufByCard(KeywordBuf.BreakProtection, 2, this.owner);
        }
    }
}
