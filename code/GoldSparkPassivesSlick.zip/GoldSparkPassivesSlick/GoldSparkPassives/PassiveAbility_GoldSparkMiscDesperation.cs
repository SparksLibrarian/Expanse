﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using UnityEngine;

namespace GoldSparkPassives
{

    public class PassiveAbility_GoldSparkMiscDesperation : PassiveAbilityBase
    {
        private int _allDmg;

        public override void OnRoundStart()
        {
            int stack = Mathf.Min(2, this._allDmg / (int)((double)this.owner.MaxHp * 0.300000011920929));
            if (stack <= 0)
                return;
            this.owner.bufListDetail.AddKeywordBufThisRoundByEtc(KeywordBuf.Strength, stack, this.owner);
            this.owner.bufListDetail.AddKeywordBufThisRoundByEtc(KeywordBuf.Endurance, stack, this.owner);
            this.owner.bufListDetail.AddKeywordBufThisRoundByEtc(KeywordBuf.Quickness, stack, this.owner);
        }

        public override void OnLoseHp(int dmg) => this._allDmg += dmg;
    }
}