﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using LOR_DiceSystem;

namespace GoldSparkPassives
{
    public class PassiveAbility_GoldSparkCourierTrailblazer : PassiveAbilityBase
    {
        public override void BeforeGiveDamage(BattleDiceBehavior behavior)
        {
            int? nullable = behavior.card?.target?.speedDiceResult[behavior.card.targetSlotOrder].value;
            int? speedDiceResultValue = behavior.card?.speedDiceResultValue;
            if (!(nullable.GetValueOrDefault() < speedDiceResultValue.GetValueOrDefault() & nullable.HasValue & speedDiceResultValue.HasValue))
                return;
            this.owner.battleCardResultLog?.SetPassiveAbility((PassiveAbilityBase)this);
            behavior.ApplyDiceStatBonus(new DiceStatBonus()
            {
                dmg = 3
            });
        }
    }

}
